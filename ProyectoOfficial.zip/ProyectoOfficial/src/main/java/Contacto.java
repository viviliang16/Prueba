import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
/**
 *
 * @author viviana_liang
 */
public class Contacto {
String nombre;
String correo;
int telefono;
String numCadena;
String descripcion; 
String direccion;

    Contacto() {
    }

public void Persona(String nombre, String correo, String numCadena, String descripcion, String direccion){
FileWriter fichero= null;
PrintWriter print= null;

try{
fichero= new FileWriter("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Contacto.txt",true);
int tempTel=Integer.parseInt(numCadena);
print= new PrintWriter(fichero);
print.println(nombre + "#" +correo+ "#"+numCadena+ "#" +descripcion+ "#" +direccion);

fichero.close();
print.close();

} catch (Exception e) {
    System.out.println("Existe un error en la escritura");
    System.out.println(e.getMessage());
    e.printStackTrace();
    }
}//Fin del metodo

public void Modificar(String nombre, String correo, String numCadena, String descripcion, String direccion){
ArrayList<String> infoL = new ArrayList<String>(); //Maneja una lista
File f=new File("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Contacto.txt");
FileWriter fichero = null;
PrintWriter pw = null;
String inf;
if(f.exists()){
    try{
FileReader fr=new FileReader(f);
BufferedReader b = new BufferedReader(fr);
while((inf=b.readLine())!=null){
String[] n = inf.split("#");
if (!n[0].equals(nombre))
{
infoL.add(inf);
}
else
{
    infoL.add(nombre + "#" + correo+ "#" + Integer.parseInt(numCadena) + "#" + descripcion+ "#" +direccion);
    }
}
fr.close();
b.close();
File newfile = new File("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Contacto.txt"); 
newfile.delete();
fichero = new FileWriter("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Contacto.txt"); 
pw = new PrintWriter(fichero);
for (int i = 0; i < infoL.size(); i++)
pw.println(infoL.get(i).toString());

pw.close();
fichero.close();
    }catch(IOException ex){ex.printStackTrace();}
finally
    {}
  }
} //Fin de metodo

public void Eliminar(String nombre)
    { 
        ArrayList<String> al = new ArrayList<String>();
        File f=new File("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Contacto.txt");
        FileWriter fichero = null;
        PrintWriter pw = null;
        String inf;
        if(f.exists()){
           try{
             FileReader fr=new FileReader(f);
             BufferedReader b = new BufferedReader(fr);
             while((inf=b.readLine())!=null){
                 String[] n = inf.split("#");
                 if (!n[0].equals(nombre))
                 {
                         al.add(inf);
                 }
             }
              fr.close();
              b.close();
              File newfile = new File("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Contacto.txt");
              newfile.delete();
              fichero = new FileWriter("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Contacto.txt");
              pw = new PrintWriter(fichero);
              for (int i = 0; i < al.size(); i++)
                pw.println(al.get(i).toString());

              pw.close();
              fichero.close();
            }catch(IOException ex){ex.printStackTrace();}
           finally
           {
           }    
    }
    }
    public Contacto(String nombre, String correo, int telefono, String descripcion, String direccion) {
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;
        this.descripcion = descripcion;
        this.direccion = direccion;
    }
    
    public String string;

    Contacto(String nombre, String SegundoApellido, String correo, String descripcion, int telefono) {
    }

    public String getString(){
    return string;
    }
    
    public void setString(String string){
        this.string= string;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    @Override
    public String toString() {
        return nombre + "#" +correo+ "#" +telefono+ "#" +descripcion+ "#" +direccion;
    }

    }
