

import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.io.*;
/**
 *
 * @author viviana_liang
 */
public class Informacion_Personal {

String nombre;
String fecha;
String Puesto;
String sexo;
int cel;
String tel;
String correo;

    public Informacion_Personal() {
     
    }
public void Ingresar(String nombre, String fecha , String puesto, String sexo, String tel, String correo ) //Se inserta la informacion personal en los archivos
{
FileWriter archivo= null;
PrintWriter impresion= null;

try {
archivo= new FileWriter("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Informacion_Personal.txt",true);
int tempCel= Integer.parseInt(tel);
impresion= new PrintWriter(archivo);
impresion.println(nombre + "#" +fecha+ "#" +puesto+ "#" +sexo+ "#" +tempCel+ "#"+correo);

archivo.close();
impresion.close();

} catch (Exception e) {
    System.out.println("Existe un error en la escritura");
    System.out.println(e.getMessage());
    e.printStackTrace();
    }

}//Fin del metodo

public void Modificar(String nombre, String fecha, String puesto, String sexo, String tel, String correo){
ArrayList<String> infoL = new ArrayList<String>(); //Maneja una lista
File f=new File("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Informacion_Personal.txt");
FileWriter fichero = null;
PrintWriter pw = null;
String inf;
if(f.exists()){
    try{
FileReader fr=new FileReader(f);
BufferedReader b = new BufferedReader(fr);
while((inf=b.readLine())!=null){
String[] n = inf.split("#");
if (!n[0].equals(nombre))
{
infoL.add(inf);
}
else
{
infoL.add(nombre + "#" +fecha+ "#" +puesto+ "#" +sexo+ "#" +Integer.parseInt(tel)+ "#"+correo);
  } //Este solo consiste en un campo
}
fr.close();
b.close();
File newfile = new File("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Informacion_Personal.txt");
newfile.delete();
fichero = new FileWriter("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Informacion_Personal.txt");
pw = new PrintWriter(fichero);
for (int i = 0; i < infoL.size(); i++)
pw.println(infoL.get(i).toString());

pw.close();
fichero.close();
    }catch(IOException ex){ex.printStackTrace();}
finally
    {}
  }
} 

public void Eliminar(String nombre)
    { 
        ArrayList<String> al = new ArrayList<String>();
        File f=new File("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Informacion_Personal.txt");
        FileWriter fichero = null;
        PrintWriter pw = null;
        String inf;
        if(f.exists()){
           try{
             FileReader fr=new FileReader(f);
             BufferedReader b = new BufferedReader(fr);
             while((inf=b.readLine())!=null){
                 String[] n = inf.split("#");
                 if (!n[0].equals(nombre))
                 {
                         al.add(inf);
                 }
             }
              fr.close();
              b.close();
              File newfile = new File("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Informacion_Personal.txt");
              newfile.delete();
              fichero = new FileWriter("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Informacion_Personal.txt");
              pw = new PrintWriter(fichero);
              for (int i = 0; i < al.size(); i++)
                pw.println(al.get(i).toString());

              pw.close();
              fichero.close();
            }catch(IOException ex){ex.printStackTrace();}
           finally
           {
           }    
    }
  }

    public Informacion_Personal(String nombre, String fecha, String Puesto, String sexo, int cel, String tel, String correo) {
        this.nombre = nombre;
        this.fecha= fecha;
        this.Puesto = Puesto;
        this.sexo = sexo;
        this.cel = cel;
        this.tel = tel;
        this.correo = correo;
    }

public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    public String getPuesto() {
        return Puesto;
    }
    public void setPuesto(String Puesto) {
        this.Puesto = Puesto;
    }
    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public int getCel() {
        return cel;
    }

    public void setCel(int cel) {
        this.cel = cel;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
}
