
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author viviana_liang
 */
public class Agenda {

String espacio;
String Descripcion;
String valor;
  public Agenda() {  
  }

public void Insertar(String valor, String espacio, String Descripcion ){
FileWriter archivo= null;
PrintWriter impresion= null;

try {
archivo= new FileWriter("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Agenda.txt",true);
impresion= new PrintWriter(archivo);
impresion.println(valor+ "#" +espacio+ "#" +Descripcion);
archivo.close();
impresion.close();

} catch (Exception e) {
    System.out.println("Existe un error en la escritura");
    System.out.println(e.getMessage());
    e.printStackTrace();
    }
} //Fin de metodo    

public void Modificar(String vr, String e, String d){
ArrayList<String> al = new ArrayList<String>(); //Maneja una lista
File f=new File("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Agenda.txt");
FileWriter fichero = null;
PrintWriter pw = null;
String inf;
if(f.exists()){
    try{
FileReader fr=new FileReader(f);
BufferedReader b = new BufferedReader(fr);
while((inf=b.readLine())!=null){
String[] n = inf.split("#");
if (!n[0].equals(vr))
{
al.add(inf);
}
else
{
    al.add( vr+ "#" +e+ "#" +d);
    }
}
fr.close();
b.close();
File newfile = new File("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Agenda.txt"); 
newfile.delete();
fichero = new FileWriter("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Agenda.txt");
pw = new PrintWriter(fichero);
for (int i = 0; i < al.size(); i++)
pw.println(al.get(i).toString());

pw.close();
fichero.close();
    }catch(IOException ex){ex.printStackTrace();}
finally
    {}
        }
} //Fin de metodo

public void Eliminar(String valor)
    { 
        ArrayList<String> al = new ArrayList<String>();
        File f=new File("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Agenda.txt");
        FileWriter fichero = null;
        PrintWriter pw = null;
        String inf;
        if(f.exists()){
           try{
             FileReader fr=new FileReader(f);
             BufferedReader b = new BufferedReader(fr);
             while((inf=b.readLine())!=null){
                 String[] n = inf.split("#");
                 if (!n[0].equals(valor))
                 {
                         al.add(inf);
                 }
             }
              fr.close();
              b.close();
              File newfile = new File("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Agenda.txt");
              newfile.delete();
              fichero = new FileWriter("C:\\Users\\vivil\\OneDrive\\Documentos\\Programacion I\\ProyectoOfficial\\Agenda.txt");
              pw = new PrintWriter(fichero);
              for (int i = 0; i < al.size(); i++)
                pw.println(al.get(i).toString());

              pw.close();
              fichero.close();
            }catch(IOException ex){ex.printStackTrace();}
           finally
           {
           }    
    }
    }


    public Agenda(String valor, String espacio, String Descripcion) {
        this.espacio = espacio;
        this.Descripcion = Descripcion;
        this.valor = valor;
    }

    public String getEspacio() {
        return espacio;
    }

    public void setEspacio(String espacio) {
        this.espacio = espacio;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }
    
}
